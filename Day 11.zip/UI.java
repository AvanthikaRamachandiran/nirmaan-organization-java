package day14;

import java.util.Scanner;

public class UI {
	public static void main(String[]args) {
		Scanner sc=new Scanner(System.in);
		Accountdetails acc=new Accountdetails();
		boolean iswork=true;
		while(iswork) {
			System.out.println("enter 1 for add create account:");
			System.out.println("enter 2 for withdrawl:");
			System.out.println("enter 3 for show account details account:");
			System.out.println("enter 4 for deposit:");
			System.out.println("enter 5 for exit:");
			int key=sc.nextInt();
			if(key==1) {
				System.out.println("enter the account no");
				int accountno=sc.nextInt();
				sc.nextLine();
				System.out.println("enter the id");
				int id=sc.nextInt();
				System.out.println("enter the name:");
				String name=sc.nextLine();
				acc=new Accountdetails();
			}else if (key==2) {
				sc.nextLine();
				System.out.println("enter the pin:");
				int pin=sc.nextInt();
				System.out.println("enter the amount:");
				double amount=sc.nextInt();
				double existbalance=acc.getBalance();
				double total=existbalance-amount;
				System.out.println("Remaining amount:"+total);
				acc.setBalance(total,pin);
			}
			else if(key==3) {
				System.out.println(acc);
			}
			else if(key==4) {
				System.out.println("enter the pin");
				int pin=sc.nextInt();
				System.out.println("enter the amount:");
				double amount=sc.nextDouble();
				double existbalance=acc.getBalance();
				double total=existbalance+amount;
				System.out.println("remaining amount:+total");
			}
			else if(key==5) {
				break;
			}
		}
		sc.close();
	}

			



		}
	


