package day10;

public class Calculator { 
	void add(int num1,int num2){
		System.out.println("Addition :"+(num1 +num2));
	}
	void sub(int num1,int num2) {
		System.out.println("Subraction:"+(num1-num2));
	}
	void mul(int num1,int num2) {
		System.out.println("Multiplication:"+(num1*num2));
	}
	void div(int num1,int num2) {
		System.out.println("Division:"+(num1/num2));
	}
	void mod(int num1,int num2) {
		System.out.println("Modules:"+(num1%num2));
	}

}
