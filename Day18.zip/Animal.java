package day18;

public interface  Animal {
	String CATEGORY="living being";
	static boolean isMammal(String animalname) {
		return animalname.equalsIgnoreCase("dog")||
		animalname.equalsIgnoreCase("Cat")||
		animalname.equalsIgnoreCase("Human");
		
	}
		default void speak() {
			System.out.println("animal is making a sound.");
		}
		void move ();
		

				
	}
	


