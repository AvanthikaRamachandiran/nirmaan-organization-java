package day18;

 class dog implements Animal {

	@Override
	public void move() {
		// TODO Auto-generated method stub
		System.out.println("The dog runs on four legs.");
	}
		public void speak() {
			System.out.println("The dog says:woof woof!");
		}
		
	}
	class bird implements Animal{

		@Override
		public void move() {
			// TODO Auto-generated method stub
			System.out.println("The bird flies in the sky");
			
		}
		public void speak() {
			System.out.println("The bird says:chirp chirp!");
		}
		

}
